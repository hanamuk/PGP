package com.example.edgeproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import com.naver.maps.geometry.LatLng;
import com.naver.maps.geometry.Utmk;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapSdk;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.util.MarkerIcons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    ArrayList<Double> XList=new ArrayList<>();
    ArrayList <Double>YList=new ArrayList<>();
    ArrayList <String>StateList=new ArrayList<>();

    //sql 관련 내용----------------------------------------------------------
    private  static  String ip="192.168.0.4";
    private  static  String port="1433";
    private  static String Classes="net.sourceforge.jtds.jdbc.Driver";
    private  static String database="WB31"; //데이터 DB 이름  변경해서 사용
    private static String username="ccm";
    private static String password="ccm";
    private static String url="jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database;

    private Connection connection=null;
    //-----------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //지도 api 호출 후 인증
        NaverMapSdk.getInstance(this).setClient(
                new NaverMapSdk.NaverCloudPlatformClient("9vpxzu8pjl"));

        //지도 객체 생성
        FragmentManager fm = getSupportFragmentManager();
        MapFragment mapFragment = (MapFragment)fm.findFragmentById(R.id.map);
        if (mapFragment == null) {
            mapFragment = MapFragment.newInstance();
            fm.beginTransaction().add(R.id.map, mapFragment).commit();
        }

        mapFragment.getMapAsync(this);
        //sql---------------------------------------------------------------------
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);
        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(Classes);
            connection= DriverManager.getConnection(url,username,password);

            Toast.makeText(MainActivity.this,"연결 성공",Toast.LENGTH_SHORT).show();

            //DB에 저장되 데이터를 배열에 저장 시킨다.
            InformationX();
            InformationY();
            InformationST();

        }catch (ClassNotFoundException e) {
            e.printStackTrace();;
            Toast.makeText(MainActivity.this,"에러 발생",Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this,"연결 실패",Toast.LENGTH_SHORT).show();
        }
        //----------------------------------------------------------------------------------------------------






}

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
     //현재 위치 초기 화면으로 표시하는 방법
        double x=36.337928;// x좌표
        double y=127.446049;//y좌표

        double xa=XList.get(0);
        double ya=YList.get(0);

        LatLng initialPosition = new LatLng(x, y); //좌표 설정
        CameraUpdate cameraUpdate = CameraUpdate.scrollTo(initialPosition);
        naverMap.moveCamera(cameraUpdate);
        //        마커 표시하는 방법
        for(int i=0;i<XList.size();i++)
        {
            Marker[] markers=new Marker[XList.size()];
            markers[i]=new Marker();
            //지도에 좌표 및 옵션 설정 -------
            markers[i].setPosition(new LatLng(XList.get(i),YList.get(i)));
            markers[i].setWidth(70);
            markers[i].setHeight(70);
            markers[i].setIcon(MarkerIcons.BLACK);
            markers[i].setIconTintColor(Color.RED);//색상
            markers[i].setIconPerspectiveEnabled(true);//원근 효과
            markers[i].setCaptionText(StateList.get(i));//아이콘
            markers[i].setCaptionOffset(20);//마커와 아이콘의 간격 조절 20pixel
            markers[i].setCaptionColor(Color.BLUE); //아이콘 색상 변경
            markers[i].setCaptionHaloColor(Color.rgb(200, 255, 200));//아이콘 색상 변경
            markers[i].setCaptionTextSize(13);//아이콘 크기
            markers[i].setMap(naverMap);//지도에 표시하기
        }
    }
    public void InformationX()
    {
        if(connection!=null)
        {
            Statement statement=null;//SQL문을 데이터베이스에 보내기위한 객체입니다.
            try{
                statement=connection.createStatement();
                ResultSet resultSetX=statement.executeQuery("select X from MyPicture;");//SQL 문장을 실행

                while(resultSetX.next()){
                    XList.add(resultSetX.getDouble("X"));

                }
                Toast.makeText(MainActivity.this,"X좌표 연결 성공",Toast.LENGTH_SHORT).show();
            } catch (SQLException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this,"X좌표 연결 실패",Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void InformationY()
    {
        if(connection!=null)
        {
            Statement statement=null;//SQL문을 데이터베이스에 보내기위한 객체입니다.
            try{
                statement=connection.createStatement();
                ResultSet resultSetY=statement.executeQuery("select Y from MyPicture;");//SQL 문장을 실행

                while(resultSetY.next()){
                    YList.add(resultSetY.getDouble("Y"));

                }
                Toast.makeText(MainActivity.this,"Y좌표 연결 성공",Toast.LENGTH_SHORT).show();
            } catch (SQLException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this,"Y좌표 연결 실패",Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void InformationST()
    {
        if(connection!=null)
        {
            Statement statement=null;//SQL문을 데이터베이스에 보내기위한 객체입니다.
            try{
                statement=connection.createStatement();
                ResultSet resultSetST=statement.executeQuery("select State from MyPicture;");//SQL 문장을 실행

                while(resultSetST.next()){
                    StateList.add(resultSetST.getString("State"));

                }
                Toast.makeText(MainActivity.this,"State 연결 성공",Toast.LENGTH_SHORT).show();
            } catch (SQLException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this,"State 연결 실패",Toast.LENGTH_SHORT).show();
            }
        }
    }

}
